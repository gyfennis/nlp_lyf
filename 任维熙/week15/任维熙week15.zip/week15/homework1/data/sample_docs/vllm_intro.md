# VLLM Memory Layout

PagedAttention 将 KV cache 按页管理，减少内存碎片。

![架构图](images/fig1.png)

## 核心机制

- 连续批处理（Continuous batching）
- 分页 KV cache（PagedAttention）

【来源文档】2309 vllm.pdf
