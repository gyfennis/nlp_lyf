"""预置样例文档到向量库，便于无 PDF 环境演示"""

import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

from app.models.orm import File as FileModel, SessionLocal
from app.services.indexing import process_upload_message

SAMPLE = os.path.join(ROOT, "data", "sample_docs", "vllm_intro.md")


def main():
    with SessionLocal() as session:
        existing = session.query(FileModel).filter(FileModel.filename == "vllm_intro.md").first()
        if existing:
            print(f"已存在 file_id={existing.id}，重新索引...")
            fid = existing.id
        else:
            rec = FileModel(
                filename="vllm_intro.md",
                filepath=SAMPLE,
                filestate="uploaded",
            )
            session.add(rec)
            session.commit()
            session.refresh(rec)
            fid = rec.id

    result = process_upload_message(fid, "vllm_intro.md", SAMPLE)
    print(result)


if __name__ == "__main__":
    main()
