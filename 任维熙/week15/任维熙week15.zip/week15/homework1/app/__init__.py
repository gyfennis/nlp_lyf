# Multimodal RAG Chatbot - Week 15 homework scaffold
