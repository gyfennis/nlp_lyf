from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    database_url: str = "sqlite:///./db.db"
    kafka_bootstrap: str = "localhost:9092"
    kafka_topic: str = "rag-data"
    index_mode: str = "inline"  # inline | kafka
    vector_store_mode: str = "local"  # local | milvus | memory
    vector_store_path: str = "data/vector_store.json"
    parse_mode: str = "auto"  # auto | mineru | markdown
    milvus_uri: str = ""
    milvus_token: str = ""
    milvus_collection: str = "rag_data_new"
    use_mock_embedding: bool = True
    use_mock_llm: bool = True
    use_mock_kafka: bool = True
    use_mock_kafka: bool = True
    bge_model_path: str = ""
    clip_model_path: str = ""
    hf_endpoint: str = "https://hf-mirror.com"
    openai_api_key: str = "EMPTY"
    openai_base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    llm_model: str = "qwen-plus"
    upload_dir: str = "uploads"
    processed_dir: str = "processed"
    mineru_url: str = "http://127.0.0.1:30000"
    chunk_size: int = 256


@lru_cache
def get_settings() -> Settings:
    return Settings()
