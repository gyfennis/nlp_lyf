from fastapi import FastAPI

from app.api import chat, files, upload

app = FastAPI(
    title="Multimodal RAG Chatbot",
    description="第十五周作业 — 多模态 RAG API（架构骨架）",
    version="0.1.0",
)

app.include_router(upload.router)
app.include_router(chat.router)
app.include_router(files.router)


@app.get("/health")
def health():
    return {"status": "ok"}
