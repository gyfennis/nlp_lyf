"""
Kafka 消费者 Worker — 复用 indexing.process_upload_message

启动: python -m app.worker.parse_worker
"""

import json
import logging

from app.core.config import get_settings
from app.services.indexing import process_upload_message

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    settings = get_settings()
    from kafka import KafkaConsumer

    consumer = KafkaConsumer(
        settings.kafka_topic,
        bootstrap_servers=settings.kafka_bootstrap,
        enable_auto_commit=True,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
    )
    logger.info("Worker 监听 topic=%s", settings.kafka_topic)
    for msg in consumer:
        v = msg.value
        logger.info("收到任务: %s", v)
        result = process_upload_message(v["id"], v["file_name"], v["file_path"])
        logger.info("处理结果: %s", result)


if __name__ == "__main__":
    main()
