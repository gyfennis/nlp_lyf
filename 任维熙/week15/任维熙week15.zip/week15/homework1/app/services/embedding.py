"""BGE + CLIP 编码 — 对齐参考 offline_precess_worker.encode_text_and_image"""

from __future__ import annotations

import hashlib
import os
import traceback
from typing import List, Tuple

import numpy as np

from app.core.config import get_settings

BGE_DIM = 512
CLIP_DIM = 1024


def _deterministic_vector(text: str, dim: int) -> List[float]:
    seed = int(hashlib.md5(text.encode()).hexdigest(), 16) % (2**32)
    rng = np.random.default_rng(seed)
    v = rng.standard_normal(dim).astype(np.float32)
    v = v / (np.linalg.norm(v) + 1e-8)
    return v.tolist()


class EmbeddingService:
    _bge = None
    _clip = None

    def __init__(self):
        self.settings = get_settings()
        if not self.settings.use_mock_embedding:
            os.environ.setdefault("HF_ENDPOINT", self.settings.hf_endpoint)

    def _load_bge(self):
        if EmbeddingService._bge is None:
            from sentence_transformers import SentenceTransformer

            EmbeddingService._bge = SentenceTransformer(self.settings.bge_model_path)
        return EmbeddingService._bge

    def _load_clip(self):
        if EmbeddingService._clip is None:
            from sentence_transformers import SentenceTransformer

            EmbeddingService._clip = SentenceTransformer(
                self.settings.clip_model_path,
                trust_remote_code=True,
                truncate_dim=CLIP_DIM,
            )
        return EmbeddingService._clip

    def encode_query(self, text: str) -> List[float]:
        if self.settings.use_mock_embedding:
            return _deterministic_vector(text, BGE_DIM)
        vec = self._load_bge().encode(text, normalize_embeddings=True)
        return list(vec)

    def encode_text_and_image(self, text: str, markdown_path: str) -> Tuple[List[float], List[float], List[float]]:
        text_with_no_image = "\n".join(line for line in text.split("\n") if not line.startswith("!["))
        text_with_image = [line for line in text.split("\n") if line.startswith("![")]

        if self.settings.use_mock_embedding:
            return (
                _deterministic_vector(text_with_no_image or text, BGE_DIM),
                _deterministic_vector((text_with_no_image or text) + ":clip", CLIP_DIM),
                _deterministic_vector((text_with_no_image or text) + ":img", CLIP_DIM),
            )

        try:
            text_bge = list(self._load_bge().encode(text_with_no_image or text, normalize_embeddings=True))
        except Exception:
            traceback.print_exc()
            text_bge = [0.0] * BGE_DIM

        try:
            text_clip = list(self._load_clip().encode(text_with_no_image or text, normalize_embeddings=True))
        except Exception:
            traceback.print_exc()
            text_clip = [0.0] * CLIP_DIM

        if text_with_image:
            image_path = text_with_image[0].split("](")[1].split(")")[0]
            image_real_path = os.path.dirname(markdown_path) + "/" + image_path.split("/")[-1]
            try:
                image_clip = list(self._load_clip().encode(image_real_path, normalize_embeddings=True))
            except Exception:
                traceback.print_exc()
                image_clip = [0.0] * CLIP_DIM
        else:
            image_clip = [0.0] * CLIP_DIM

        return text_bge, text_clip, image_clip
