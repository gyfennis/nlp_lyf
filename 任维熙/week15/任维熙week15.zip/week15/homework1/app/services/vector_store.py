"""向量存储：local JSON / Milvus / memory"""

from __future__ import annotations

import json
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional

import numpy as np

from app.core.config import get_settings

BGE_DIM = 512


@dataclass
class VectorRecord:
    text: str
    file_name: str
    file_path: str
    db_id: int
    text_vector: list[float]
    clip_text_vector: list[float]
    clip_image_vector: list[float]
    score: float = 0.0


class BaseVectorStore(ABC):
    @abstractmethod
    def insert(self, record: dict) -> None: ...

    @abstractmethod
    def search(self, query_vector: list[float], top_k: int = 5) -> List[VectorRecord]: ...

    @abstractmethod
    def delete_by_db_id(self, db_id: int) -> int: ...


class MemoryVectorStore(BaseVectorStore):
    _instance: Optional["MemoryVectorStore"] = None
    _records: list[dict]

    def __init__(self):
        self._records = []

    @classmethod
    def instance(cls) -> "MemoryVectorStore":
        if cls._instance is None:
            cls._instance = MemoryVectorStore()
        return cls._instance

    @classmethod
    def reset(cls):
        if cls._instance:
            cls._instance._records = []

    def insert(self, record: dict) -> None:
        self._records.append(dict(record))

    def search(self, query_vector: list[float], top_k: int = 5) -> List[VectorRecord]:
        return _rank_records(self._records, query_vector, top_k)

    def delete_by_db_id(self, db_id: int) -> int:
        before = len(self._records)
        self._records = [r for r in self._records if r.get("db_id") != db_id]
        return before - len(self._records)


class LocalJsonVectorStore(BaseVectorStore):
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self._records: list[dict] = []
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path, encoding="utf-8") as f:
                self._records = json.load(f)
        else:
            self._records = []

    def _save(self):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self._records, f, ensure_ascii=False)

    def insert(self, record: dict) -> None:
        self._records.append(dict(record))
        self._save()

    def search(self, query_vector: list[float], top_k: int = 5) -> List[VectorRecord]:
        return _rank_records(self._records, query_vector, top_k)

    def delete_by_db_id(self, db_id: int) -> int:
        before = len(self._records)
        self._records = [r for r in self._records if r.get("db_id") != db_id]
        if before != len(self._records):
            self._save()
        return before - len(self._records)


class MilvusVectorStore(BaseVectorStore):
    def __init__(self):
        from pymilvus import MilvusClient

        s = get_settings()
        self.client = MilvusClient(uri=s.milvus_uri, token=s.milvus_token)
        self.collection = s.milvus_collection

    def insert(self, record: dict) -> None:
        self.client.insert(collection_name=self.collection, data=[record])

    def search(self, query_vector: list[float], top_k: int = 5) -> List[VectorRecord]:
        results = self.client.search(
            collection_name=self.collection,
            data=[query_vector],
            limit=top_k,
            anns_field="text_vector",
            output_fields=["text", "db_id", "file_name", "file_path"],
        )
        out: List[VectorRecord] = []
        for hit in results[0]:
            ent = hit.get("entity", hit)
            out.append(
                VectorRecord(
                    text=ent.get("text", ""),
                    file_name=ent.get("file_name", ""),
                    file_path=ent.get("file_path", ""),
                    db_id=ent.get("db_id", -1),
                    text_vector=[],
                    clip_text_vector=[],
                    clip_image_vector=[],
                    score=float(hit.get("distance", hit.get("score", 0))),
                )
            )
        return out

    def delete_by_db_id(self, db_id: int) -> int:
        self.client.delete(collection_name=self.collection, filter=f"db_id == {db_id}")
        return 1


def _rank_records(records: list[dict], query_vector: list[float], top_k: int) -> List[VectorRecord]:
    if not records:
        return []
    q = np.array(query_vector, dtype=np.float32)
    scored = []
    for r in records:
        v = np.array(r["text_vector"], dtype=np.float32)
        score = float(np.dot(q, v))
        scored.append((score, r))
    scored.sort(key=lambda x: x[0], reverse=True)
    out = []
    for score, r in scored[:top_k]:
        out.append(
            VectorRecord(
                text=r["text"],
                file_name=r.get("file_name", ""),
                file_path=r.get("file_path", ""),
                db_id=r.get("db_id", -1),
                text_vector=r.get("text_vector", []),
                clip_text_vector=r.get("clip_text_vector", []),
                clip_image_vector=r.get("clip_image_vector", []),
                score=score,
            )
        )
    return out


_store: Optional[BaseVectorStore] = None


def get_vector_store() -> BaseVectorStore:
    global _store
    if _store is not None:
        return _store
    s = get_settings()
    mode = s.vector_store_mode
    if mode == "memory":
        _store = MemoryVectorStore.instance()
    elif mode == "milvus" and s.milvus_uri:
        _store = MilvusVectorStore()
    else:
        _store = LocalJsonVectorStore(s.vector_store_path)
    return _store


def reset_vector_store():
    global _store
    _store = None
    MemoryVectorStore.reset()
