"""文档离线索引 — 对齐 offline_precess_worker + 支持 txt/md 直索引"""

from __future__ import annotations

import glob
import logging
import os
import shutil
import subprocess
import threading
from typing import Optional

from app.core.config import get_settings
from app.models.orm import File as FileModel, SessionLocal
from app.services.chunking import split_markdown_file
from app.services.embedding import EmbeddingService
from app.services.kafka_producer import enqueue_parse_task
from app.services.vector_store import get_vector_store

logger = logging.getLogger(__name__)


def update_file_state(file_id: int, state: str):
    with SessionLocal() as session:
        row = session.query(FileModel).filter(FileModel.id == file_id).first()
        if row:
            row.filestate = state
            session.commit()


def run_mineru(file_path: str, output_dir: str) -> None:
    settings = get_settings()
    cmd = (
        f"mineru -p \"{file_path}\" -o \"{output_dir}\" "
        f"-b vlm-http-client -u {settings.mineru_url}"
    )
    logger.info("执行 MinerU: %s", cmd)
    subprocess.check_output(cmd, shell=True, timeout=600)


def resolve_markdown_paths(file_path: str, file_id: int) -> list[str]:
    settings = get_settings()
    ext = os.path.splitext(file_path)[1].lower()

    if ext in (".md", ".markdown", ".txt"):
        dest_dir = os.path.join(settings.processed_dir, str(file_id))
        os.makedirs(dest_dir, exist_ok=True)
        dest_md = os.path.join(dest_dir, "content.md")
        if file_path != dest_md:
            shutil.copy2(file_path, dest_md)
        return [dest_md]

    base = os.path.splitext(os.path.basename(file_path))[0]
    pattern = os.path.join(settings.processed_dir, base, "**", "*.md")
    paths = glob.glob(pattern, recursive=True)
    if not paths:
        pattern2 = os.path.join(settings.processed_dir, str(file_id), "**", "*.md")
        paths = glob.glob(pattern2, recursive=True)
    return paths


def index_markdown_file(md_path: str, file_id: int, file_name: str, file_path: str) -> int:
    embedder = EmbeddingService()
    store = get_vector_store()
    count = 0
    for chunk in split_markdown_file(md_path, chunk_size=get_settings().chunk_size):
        bge, clip_t, clip_i = embedder.encode_text_and_image(chunk, md_path)
        store.insert(
            {
                "text_vector": bge,
                "clip_text_vector": clip_t,
                "clip_image_vector": clip_i,
                "text": chunk,
                "db_id": file_id,
                "file_name": file_name,
                "file_path": file_path,
            }
        )
        count += 1
    return count


def process_upload_message(file_id: int, file_name: str, file_path: str) -> dict:
    """完整索引流水线，供 Worker 与内联模式共用"""
    settings = get_settings()
    if not os.path.exists(file_path):
        update_file_state(file_id, "failed")
        return {"ok": False, "error": "file not found"}

    update_file_state(file_id, "parsing")
    try:
        ext = os.path.splitext(file_path)[1].lower()
        need_mineru = ext == ".pdf" and settings.parse_mode in ("auto", "mineru")

        if need_mineru:
            try:
                os.makedirs(settings.processed_dir, exist_ok=True)
                run_mineru(file_path, settings.processed_dir)
            except Exception as e:
                logger.warning("MinerU 失败，尝试直读已存在 markdown: %s", e)

        md_paths = resolve_markdown_paths(file_path, file_id)
        if not md_paths:
            update_file_state(file_id, "failed")
            return {"ok": False, "error": "no markdown found"}

        total = 0
        for md in md_paths:
            total += index_markdown_file(md, file_id, file_name, file_path)

        update_file_state(file_id, "indexed")
        return {"ok": True, "chunks": total, "markdown": md_paths[0]}
    except Exception as e:
        logger.exception("索引失败")
        update_file_state(file_id, "failed")
        return {"ok": False, "error": str(e)}


def schedule_index(file_id: int, file_name: str, file_path: str):
    settings = get_settings()
    if settings.index_mode == "kafka" and not settings.use_mock_kafka:
        enqueue_parse_task(file_id, file_name, file_path)
        return

    def _run():
        process_upload_message(file_id, file_name, file_path)

    threading.Thread(target=_run, daemon=True).start()
