"""检索服务 — 对齐 web_page_chat.py"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List

from app.core.config import get_settings
from app.services.embedding import EmbeddingService
from app.services.vector_store import VectorRecord, get_vector_store


@dataclass
class RetrievedChunk:
    text: str
    file_name: str
    file_path: str
    db_id: int
    score: float = 0.0


class RetrievalService:
    def __init__(self):
        self.settings = get_settings()
        self.embedder = EmbeddingService()
        self.store = get_vector_store()

    def fix_image_paths(self, text: str, file_path: str) -> str:
        file_dir = os.path.basename(file_path).split(".")[0]
        prefix = f"./{self.settings.processed_dir}/{file_dir}/vlm/images/"
        return text.replace("images/", prefix)

    def retrieve(self, question: str, top_k: int = 5) -> List[RetrievedChunk]:
        qvec = self.embedder.encode_query(question)
        hits: List[VectorRecord] = self.store.search(qvec, top_k=top_k)
        out = []
        for h in hits:
            out.append(
                RetrievedChunk(
                    text=self.fix_image_paths(h.text, h.file_path),
                    file_name=h.file_name,
                    file_path=h.file_path,
                    db_id=h.db_id,
                    score=h.score,
                )
            )
        return out

    def build_context(self, chunks: List[RetrievedChunk]) -> str:
        return "\n".join(c.text for c in chunks)
