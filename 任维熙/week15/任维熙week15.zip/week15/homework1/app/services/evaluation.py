"""课程评测：页面匹配 + 文件名匹配 + Jaccard"""


def jaccard_similarity(a: str, b: str) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    union = len(sa | sb)
    return len(sa & sb) / union if union else 0.0


def evaluate_answer(answer: str, expected: dict, reference_answer: str = "") -> dict:
    fn = 0.25 if expected.get("expected_file", "") in answer else 0.0
    page_hint = expected.get("expected_page_hint", "")
    pg = 0.25 if (not page_hint or page_hint in answer) else 0.0
    jaccard = jaccard_similarity(answer, reference_answer) * 0.5 if reference_answer else 0.0
    keyword_score = 0.0
    for kw in expected.get("expected_answer_keywords", []):
        if kw.lower() in answer.lower():
            keyword_score = max(keyword_score, 0.25)
    content = max(jaccard, keyword_score)
    total = min(fn + pg + content, 1.0)
    return {
        "filename_score": fn,
        "page_score": pg,
        "content_score": content,
        "total": total,
    }
