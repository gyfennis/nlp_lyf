RAG_PROMPT = """基于资料回答的提问问题：{question}

相关资料:
{context}

回答要求：
- 回答要客观，有逻辑，要基于已有的资料。
- 如果资料中包含图片链接，则单独一行进行输出，保留图的原始链接，需要将图放在合适的相关内容的位置。
- 在答案末尾用一行注明信息来源，格式：【来源】文件名1, 文件名2
"""


class QAService:
    def __init__(self):
        from app.core.config import get_settings

        self.settings = get_settings()

    def answer(self, question: str, context: str, sources: list[dict]) -> str:
        source_names = ", ".join(
            sorted({s.get("file_name", "") for s in sources if s.get("file_name")})
        )
        if self.settings.use_mock_llm:
            preview = context[:300].replace("\n", " ")
            return (
                f"根据知识库资料，针对「{question}」：\n\n{preview}...\n\n"
                f"【来源】{source_names or '无'}"
            )
        try:
            from openai import OpenAI

            client = OpenAI(
                api_key=self.settings.openai_api_key,
                base_url=self.settings.openai_base_url,
            )
            completion = client.chat.completions.create(
                model=self.settings.llm_model,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {
                        "role": "user",
                        "content": RAG_PROMPT.format(question=question, context=context),
                    },
                ],
            )
            content = completion.choices[0].message.content or ""
            if source_names and "【来源】" not in content:
                content += f"\n\n【来源】{source_names}"
            return content
        except Exception as e:
            return f"[LLM 调用失败] {e}\n【来源】{source_names}"
