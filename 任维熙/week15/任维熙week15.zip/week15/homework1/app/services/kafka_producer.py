import json
import logging

from app.core.config import get_settings

logger = logging.getLogger(__name__)


def enqueue_parse_task(file_id: int, file_name: str, file_path: str) -> bool:
    settings = get_settings()
    payload = {"id": file_id, "file_name": file_name, "file_path": file_path}
    if settings.use_mock_kafka:
        logger.info("[Mock Kafka] topic=%s payload=%s", settings.kafka_topic, payload)
        return True
    try:
        from kafka import KafkaProducer

        producer = KafkaProducer(
            bootstrap_servers=settings.kafka_bootstrap,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        )
        producer.send(settings.kafka_topic, value=payload)
        producer.flush()
        return True
    except Exception as e:
        logger.error("Kafka send failed: %s", e)
        return False
