"""文本切分 — 对齐参考项目 offline_precess_worker.split_text2chunks"""


def split_text2chunks(lines: list[str], chunk_size: int = 256) -> list[str]:
    chunks: list[str] = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line == "# References":
            continue
        if len(line) > 2 and line[0] == "[" and line[1].isdigit():
            continue
        if not chunks:
            chunks.append(line)
        elif len(chunks[-1]) <= chunk_size:
            chunks[-1] += "\n" + line
        else:
            chunks.append(line)
    return chunks


def split_markdown_file(path: str, chunk_size: int = 256) -> list[str]:
    with open(path, encoding="utf-8") as f:
        return split_text2chunks(f.readlines(), chunk_size=chunk_size)
