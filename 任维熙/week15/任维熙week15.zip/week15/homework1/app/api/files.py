import os

from fastapi import APIRouter, HTTPException

from app.api.schemas import FileItem
from app.models.orm import File as FileModel, SessionLocal
from app.services.vector_store import get_vector_store

router = APIRouter(tags=["files"])


@router.get("/files", response_model=list[FileItem])
def list_files():
    with SessionLocal() as session:
        rows = session.query(FileModel).all()
        return [
            FileItem(
                id=r.id,
                filename=r.filename,
                filepath=r.filepath,
                filestate=r.filestate,
                knowledge_base_id=r.knowledge_base_id,
            )
            for r in rows
        ]


@router.delete("/files/{file_id}")
def delete_file(file_id: int):
    with SessionLocal() as session:
        record = session.query(FileModel).filter(FileModel.id == file_id).first()
        if not record:
            raise HTTPException(status_code=404, detail="文件不存在")
        path = record.filepath
        session.delete(record)
        session.commit()

    if path and os.path.exists(path):
        os.remove(path)

    removed = get_vector_store().delete_by_db_id(file_id)
    return {"ok": True, "file_id": file_id, "vectors_removed": removed}
