import os
import uuid

from fastapi import APIRouter, File, Form, UploadFile

from app.api.schemas import UploadResponse
from app.core.config import get_settings
from app.models.orm import File as FileModel, SessionLocal
from app.services.indexing import schedule_index

router = APIRouter(tags=["upload"])


@router.post("/upload/document", response_model=UploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    knowledge_base_id: str = Form(default="default"),
):
    settings = get_settings()
    os.makedirs(settings.upload_dir, exist_ok=True)

    ext = os.path.splitext(file.filename or "doc.pdf")[1] or ".pdf"
    save_name = str(uuid.uuid4())
    save_path = os.path.join(settings.upload_dir, save_name + ext)

    content = await file.read()
    with open(save_path, "wb") as f:
        f.write(content)

    with SessionLocal() as session:
        record = FileModel(
            filename=file.filename or save_name,
            filepath=save_path,
            filestate="uploaded",
            knowledge_base_id=knowledge_base_id,
        )
        session.add(record)
        session.commit()
        session.refresh(record)
        file_id = record.id

    schedule_index(file_id, record.filename, save_path)

    return UploadResponse(
        file_id=file_id,
        filename=record.filename,
        filepath=save_path,
        state="uploaded",
        message="已提交后台索引（inline 或 Kafka）",
    )
