from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    question: str
    knowledge_base_id: str = "default"
    top_k: int = Field(default=5, ge=1, le=20)


class SourceItem(BaseModel):
    file_name: str
    file_path: str
    snippet: str


class ChatResponse(BaseModel):
    answer: str
    sources: list[SourceItem]
    retrieved_chunks: int


class UploadResponse(BaseModel):
    file_id: int
    filename: str
    filepath: str
    state: str
    message: str


class FileItem(BaseModel):
    id: int
    filename: str
    filepath: str
    filestate: str
    knowledge_base_id: str
