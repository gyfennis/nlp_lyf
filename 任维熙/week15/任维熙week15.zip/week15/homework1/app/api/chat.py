from fastapi import APIRouter

from app.api.schemas import ChatRequest, ChatResponse, SourceItem
from app.services.qa import QAService
from app.services.retrieval import RetrievalService

router = APIRouter(tags=["chat"])


@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    retrieval = RetrievalService()
    chunks = retrieval.retrieve(req.question, top_k=req.top_k)
    context = retrieval.build_context(chunks)

    sources = [
        SourceItem(
            file_name=c.file_name,
            file_path=c.file_path,
            snippet=c.text[:200],
        )
        for c in chunks
    ]

    qa = QAService()
    answer = qa.answer(req.question, context, [s.model_dump() for s in sources])

    return ChatResponse(
        answer=answer,
        sources=sources,
        retrieved_chunks=len(chunks),
    )
