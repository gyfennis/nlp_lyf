import os
from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.core.config import get_settings

Base = declarative_base()


class File(Base):
    __tablename__ = "files"

    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(255), nullable=False)
    filepath = Column(String(1000), nullable=False)
    filestate = Column(String(20), nullable=False, default="uploaded")
    knowledge_base_id = Column(String(64), nullable=False, default="default")


def _engine():
    settings = get_settings()
    url = settings.database_url
    if url.startswith("sqlite"):
        path = url.replace("sqlite:///", "")
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    return create_engine(url, connect_args={"check_same_thread": False} if "sqlite" in url else {})


engine = _engine()
Base.metadata.create_all(engine)
SessionLocal = sessionmaker(bind=engine)
