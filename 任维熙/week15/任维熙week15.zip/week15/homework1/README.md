# 多模态 RAG Chatbot（第十五周作业）

基于 `05-multimodal-rag-chatbot` 参考实现的多模态检索增强问答系统。

## 功能清单

见 [REQUIREMENTS.md](./REQUIREMENTS.md)（F1–F12 功能与实现规定）。

## 快速开始

```powershell
cd "05-multimodal-rag-chatbot-cc"
pip install -r requirements.txt
copy .env.example .env

# 预置样例文档到向量库
python scripts/seed_sample.py

# 运行测试
python -m pytest tests/ -v

# 启动 API
uvicorn app.main:app --reload --port 8000

# 启动 Streamlit（另开终端）
cd web_ui
streamlit run web_demo.py
```

## API 示例

```powershell
# 上传 markdown
curl -X POST "http://127.0.0.1:8000/upload/document" -F "file=@data/sample_docs/vllm_intro.md"

# 问答
curl -X POST "http://127.0.0.1:8000/chat" -H "Content-Type: application/json" -d "{\"question\":\"什么是 PagedAttention？\",\"top_k\":5}"

# 文件列表
curl http://127.0.0.1:8000/files
```

## 配置说明

| 变量 | 默认 | 说明 |
|------|------|------|
| `VECTOR_STORE_MODE` | `local` | `local` JSON / `milvus` / 测试用 `memory` |
| `INDEX_MODE` | `inline` | 上传后后台线程索引；`kafka` 需 Worker |
| `USE_MOCK_EMBEDDING` | `true` | 无 GPU 时用确定性向量 |
| `USE_MOCK_LLM` | `true` | 无 API Key 时返回模板答案 |

对接真实模型时，在 `.env` 中设置：

```
USE_MOCK_EMBEDDING=false
USE_MOCK_LLM=false
BGE_MODEL_PATH=/path/to/bge-small-zh-v1.5
CLIP_MODEL_PATH=/path/to/jina-clip-v2
OPENAI_API_KEY=sk-...
```

## 进程架构

| 进程 | 命令 | 作用 |
|------|------|------|
| API | `uvicorn app.main:app` | REST 接口 |
| UI | `streamlit run web_ui/web_demo.py` | 文件管理 + 图文对话 |
| Worker | `python -m app.worker.parse_worker` | Kafka 消费（`INDEX_MODE=kafka`） |

## 项目结构

```
app/api/          FastAPI 路由
app/services/     业务逻辑（与参考代码对齐）
app/worker/       Kafka 消费者
web_ui/           Streamlit 双页
tests/            单元与接口测试
data/sample_docs/ 演示用 Markdown
scripts/          工具脚本
```

## 参考对照

| 参考文件 | 本仓库 |
|----------|--------|
| `web_page_upload.py` | `web_ui/web_page_upload.py` + `app/api/upload.py` |
| `web_page_chat.py` | `web_ui/web_page_chat.py` + `app/api/chat.py` |
| `offline_precess_worker.py` | `app/services/indexing.py` + `app/worker/parse_worker.py` |
