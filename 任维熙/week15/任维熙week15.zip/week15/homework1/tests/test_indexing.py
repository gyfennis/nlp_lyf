import os

from app.models.orm import File as FileModel, SessionLocal
from app.services.indexing import process_upload_message
from app.services.vector_store import get_vector_store

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SAMPLE = os.path.join(ROOT, "data", "sample_docs", "vllm_intro.md")


def test_index_markdown_inline():
    with SessionLocal() as session:
        rec = FileModel(filename="vllm_intro.md", filepath=SAMPLE, filestate="uploaded")
        session.add(rec)
        session.commit()
        session.refresh(rec)
        fid = rec.id

    result = process_upload_message(fid, "vllm_intro.md", SAMPLE)
    assert result["ok"] is True
    assert result["chunks"] >= 1

    from app.services.embedding import EmbeddingService

    store = get_vector_store()
    hits = store.search(EmbeddingService().encode_query("PagedAttention KV cache"), top_k=3)
    assert len(hits) >= 1
    assert any("PagedAttention" in h.text for h in hits)

    with SessionLocal() as session:
        row = session.query(FileModel).filter(FileModel.id == fid).first()
        assert row.filestate == "indexed"
