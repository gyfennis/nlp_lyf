import os
import sys

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

os.environ.setdefault("VECTOR_STORE_MODE", "memory")
os.environ.setdefault("USE_MOCK_EMBEDDING", "true")
os.environ.setdefault("USE_MOCK_LLM", "true")
os.environ.setdefault("USE_MOCK_KAFKA", "true")
os.environ.setdefault("INDEX_MODE", "inline")
os.environ.setdefault("DATABASE_URL", f"sqlite:///{os.path.join(ROOT, 'test_db.db')}")


@pytest.fixture(autouse=True)
def reset_stores():
    from app.services.vector_store import MemoryVectorStore, reset_vector_store

    reset_vector_store()
    MemoryVectorStore.reset()
    yield
    reset_vector_store()
    MemoryVectorStore.reset()
