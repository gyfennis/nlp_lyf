import io
import json
import os
import time

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.services.embedding import EmbeddingService
from app.services.vector_store import get_vector_store

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


@pytest.fixture
def client():
    return TestClient(app)


def _seed_milvus():
    path = os.path.join(FIXTURES, "sample_chunks.json")
    raw = json.load(open(path, encoding="utf-8"))
    embedder = EmbeddingService()
    store = get_vector_store()
    for item in raw:
        vec = embedder.encode_query(item["text"])
        store.insert(
            {
                **item,
                "text_vector": vec,
                "clip_text_vector": vec[:16],
                "clip_image_vector": vec[:16],
            }
        )


def test_health(client):
    assert client.get("/health").json()["status"] == "ok"


def test_upload_markdown_and_chat(client, tmp_path, monkeypatch):
    monkeypatch.setenv("UPLOAD_DIR", str(tmp_path))
    from app.core.config import get_settings

    get_settings.cache_clear()

    sample = os.path.join(os.path.dirname(__file__), "..", "data", "sample_docs", "vllm_intro.md")
    with open(sample, "rb") as f:
        r = client.post(
            "/upload/document",
            files={"file": ("vllm_intro.md", f, "text/markdown")},
            data={"knowledge_base_id": "default"},
        )
    assert r.status_code == 200
    file_id = r.json()["file_id"]
    time.sleep(1.5)

    r2 = client.post("/chat", json={"question": "VLLM Memory layout PagedAttention", "top_k": 3})
    assert r2.status_code == 200
    body = r2.json()
    assert body["retrieved_chunks"] >= 0

    r3 = client.get("/files")
    assert any(x["id"] == file_id for x in r3.json())


def test_chat_with_seeded_data(client):
    _seed_milvus()
    r = client.post("/chat", json={"question": "VLLM Memory layout PagedAttention", "top_k": 3})
    body = r.json()
    assert body["retrieved_chunks"] >= 1
    assert "answer" in body
