from app.services.chunking import split_text2chunks


def test_split_skips_references():
    lines = ["# Intro", "hello", "# References", "[1] cite", "tail"]
    chunks = split_text2chunks(lines, chunk_size=1000)
    assert any("hello" in c for c in chunks)
    assert not any("References" in c for c in chunks)
    assert not any(c.startswith("[1]") for c in chunks)


def test_merge_small_lines():
    lines = ["line a", "line b", "x" * 300]
    chunks = split_text2chunks(lines, chunk_size=50)
    # 前两行合并；超长行单独成块
    assert len(chunks) >= 1
    assert "line a" in chunks[0]
    assert any(len(c) > 50 for c in chunks)
