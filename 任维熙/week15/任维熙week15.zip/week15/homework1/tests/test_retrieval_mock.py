from app.services.embedding import EmbeddingService
from app.services.retrieval import RetrievalService
from app.services.vector_store import MemoryVectorStore, get_vector_store


def test_mock_search_returns_ordered_results():
    embedder = EmbeddingService()
    text = "PagedAttention KV cache"
    vec = embedder.encode_query(text)
    store = get_vector_store()
    store.insert(
        {
            "text_vector": vec,
            "text": text,
            "file_name": "2309 vllm.pdf",
            "file_path": "uploads/demo-vllm.pdf",
            "db_id": 1,
            "clip_text_vector": vec[:16],
            "clip_image_vector": vec[:16],
        }
    )
    store.insert(
        {
            "text_vector": embedder.encode_query("unrelated topic"),
            "text": "other",
            "file_name": "b.pdf",
            "file_path": "uploads/b.pdf",
            "db_id": 2,
            "clip_text_vector": [],
            "clip_image_vector": [],
        }
    )
    svc = RetrievalService()
    hits = svc.retrieve("PagedAttention", top_k=1)
    assert len(hits) == 1
    assert "PagedAttention" in hits[0].text


def test_fix_image_paths():
    svc = RetrievalService()
    md = "see ![](images/fig1.png)"
    fixed = svc.fix_image_paths(md, "uploads/2309 vllm.pdf")
    assert "processed/2309 vllm/vlm/images/" in fixed
