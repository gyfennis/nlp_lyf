import json
import os

from app.services.evaluation import evaluate_answer, jaccard_similarity


def test_jaccard_basic():
    assert jaccard_similarity("abc", "abc") == 1.0
    assert jaccard_similarity("abc", "xyz") == 0.0
    assert 0.0 < jaccard_similarity("abc", "abd") < 1.0


def test_evaluate_with_keywords():
    expected = {
        "expected_file": "2309 vllm.pdf",
        "expected_page_hint": "",
        "expected_answer_keywords": ["PagedAttention"],
    }
    answer = "根据 2309 vllm.pdf，PagedAttention 管理 KV cache。"
    scores = evaluate_answer(answer, expected, reference_answer="PagedAttention KV cache")
    assert scores["total"] > 0.5


if __name__ == "__main__":
    fixtures = os.path.join(os.path.dirname(__file__), "fixtures", "qa_pairs.json")
    pairs = json.load(open(fixtures, encoding="utf-8"))
    mock_answer = "根据 2309 vllm.pdf 的资料，PagedAttention 用于 KV cache 分页。"
    for item in pairs:
        s = evaluate_answer(mock_answer, item, reference_answer=" ".join(item["expected_answer_keywords"]))
        print(item["question"], s)
