# 架构设计

## 总览

```
Streamlit (web_ui)  ──┐
FastAPI (app/api)   ──┼──► app/services ──► SQLite (files)
                      │         │
                      │         ├──► vector_store (local JSON / Milvus)
                      │         ├──► embedding (BGE + CLIP)
                      │         └──► qa (Qwen)
                      │
Worker (Kafka)      ──┘──► indexing.process_upload_message
```

## 实现规定摘要

1. **单一业务层**：`app/services/`，UI 与 API 不得重复实现检索逻辑。  
2. **默认可离线演示**：`VECTOR_STORE_MODE=local` + `INDEX_MODE=inline` + Mock 模型。  
3. **生产扩展**：切换 Milvus、Kafka、真实模型路径即可，无需改接口。  
4. **修正参考 bug**：MinerU 输出目录统一为 `processed/`；`rag_prompt` 不再对字符串错误 `join`。

## 索引状态机

`uploaded` → `parsing` → `indexed` | `failed`

## 详细需求

见 [REQUIREMENTS.md](./REQUIREMENTS.md)。
