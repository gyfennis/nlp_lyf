# 第十五周作业：多模态 RAG Chatbot — 功能与实现规定

> 参照目录：`../05-multimodal-rag-chatbot/`（Streamlit 参考实现）  
> 检索/问答逻辑参照：`../demo/task2.py`  
> **本仓库为完整可运行实现**，由 Agent 完成 vibe-coding，不依赖 Claude Code。

---

## 一、必须实现的功能（对照参考项目）

| 编号 | 功能 | 参考来源 | 本仓库实现位置 | 验收标准 |
|------|------|----------|----------------|----------|
| F1 | PDF/文档上传并落盘 | `web_page_upload.py` | `POST /upload/document` + `web_ui/web_page_upload.py` | 文件写入 `uploads/`，DB 有记录 |
| F2 | 上传后异步解析入队 | Kafka `rag-data` | `kafka_producer.py` 或 **内联索引** `indexing.py` | 上传后 `filestate` 变为 `parsing`→`indexed` |
| F3 | 文档解析为 Markdown+图片 | MinerU CLI | `indexing.run_mineru()` | `processed/{id}/**/*.md` 存在 |
| F4 | 文本切分 chunk | `split_text2chunks` | `chunking.py` | 过滤 References、引用行 |
| F5 | BGE 文本向量 + CLIP 图文向量 | `encode_text_and_image` | `embedding.py` | 512 + 1024 维向量写入向量库 |
| F6 | 向量存储与按 `db_id` 删除 | Milvus `rag_data_new` | `vector_store.py`（local/milvus） | 删除文件时向量同步删除 |
| F7 | 问题向量检索 Top-K | `web_page_chat.py` L90-96 | `retrieval.py` | `POST /chat` 返回 `sources` |
| F8 | 图片路径修正 | `web_page_chat.py` L100-101 | `retrieval.fix_image_paths` | `images/`→`processed/.../vlm/images/` |
| F9 | RAG Prompt + Qwen 回答 | `rag_prompt` + OpenAI 兼容 API | `qa.py` | 答案含来源文件名 |
| F10 | 文件列表与删除 | `web_page_upload.py` | `GET/DELETE /files` + Streamlit | 删 DB + 删向量 |
| F11 | Streamlit 双页导航 | `web_demo.py` | `web_ui/web_demo.py` | 文件管理 + 图文对话 |
| F12 | 课程评测脚本 | README 评价方法 | `evaluation.py` + `tests/test_evaluation.py` | Jaccard + 文件名/页匹配 |

---

## 二、各功能具体实现逻辑

以下按功能编号说明**输入 → 处理步骤 → 输出 → 关键代码**，与当前仓库实现一致。

---

### F1：PDF/文档上传并落盘

**入口**：`POST /upload/document`（`app/api/upload.py`）或 Streamlit `web_ui/web_page_upload.py`

**实现逻辑**：

```
用户选择文件 (pdf/docx/txt/md)
    ↓
生成 UUID 文件名，扩展名保留原后缀
    ↓
写入目录 uploads/{uuid}.{ext}  （配置项 UPLOAD_DIR）
    ↓
SQLite INSERT → files 表
    字段: filename=原始名, filepath=绝对/相对路径, filestate='uploaded', knowledge_base_id
    ↓
返回 JSON: { file_id, filename, filepath, state, message }
```

**关键代码路径**：

- `upload.py`：`await file.read()` → `open(save_path, "wb")` → `SessionLocal()` 插入 `FileModel`
- Streamlit 页逻辑相同，只是 UI 用 `st.file_uploader` 获取字节流

**不做的事**：上传接口内**不**同步解析 PDF，避免 HTTP 超时（与参考项目一致）。

---

### F2：上传后异步解析入队

**入口**：上传成功后调用 `indexing.schedule_index(file_id, file_name, file_path)`

**实现逻辑（由 `INDEX_MODE` 决定）**：

```
schedule_index()
    │
    ├─ INDEX_MODE == 'kafka' 且 USE_MOCK_KAFKA == false
    │       → kafka_producer.enqueue_parse_task()
    │       → 向 topic 'rag-data' 发送 JSON: { id, file_name, file_path }
    │       → 由 app/worker/parse_worker.py 消费
    │
    └─ 其他情况（默认 INDEX_MODE == 'inline'）
            → threading.Thread(target=process_upload_message, daemon=True).start()
            → 上传 HTTP 立即返回，索引在后台线程执行
```

**状态机**（`indexing.update_file_state`）：

| 阶段 | filestate | 触发时机 |
|------|-----------|----------|
| 上传完成 | `uploaded` | INSERT 时 |
| 开始索引 | `parsing` | `process_upload_message` 开头 |
| 索引成功 | `indexed` | 全部 chunk 写入向量库后 |
| 索引失败 | `failed` | 文件不存在 / 无 markdown / 异常 |

---

### F3：文档解析为 Markdown + 图片

**入口**：`indexing.process_upload_message()` 内，在 `filestate=parsing` 之后

**实现逻辑**：

```
判断文件扩展名 ext
    │
    ├─ ext ∈ {.md, .markdown, .txt}
    │       → resolve_markdown_paths()
    │       → 复制到 processed/{file_id}/content.md（无需 MinerU）
    │
    └─ ext == .pdf 且 PARSE_MODE ∈ {auto, mineru}
            → run_mineru()
            │     命令: mineru -p "{filepath}" -o "{processed_dir}" -b vlm-http-client -u {MINERU_URL}
            │     超时: 600 秒
            │     输出: processed/{pdf_basename}/vlm/*.md 及 images/*
            → glob(processed/{basename}/**/*.md) 或 processed/{file_id}/**/*.md
            │
            └─ MinerU 失败时: 记录 warning，继续尝试 glob 已有 markdown
```

**输出物**：

- 至少一个 `.md` 文件路径列表 `md_paths`
- Markdown 内图片引用形如 `![](images/xxx.png)`，实体文件在 `processed/.../vlm/images/`

**与参考项目差异**：参考代码混用 `precessed` / `processed`，本仓库**统一为 `processed`**。

---

### F4：文本切分 chunk

**入口**：`indexing.index_markdown_file()` → `chunking.split_markdown_file(path)`

**实现逻辑**（对齐 `offline_precess_worker.split_text2chunks`）：

```
按行读取 markdown
    ↓
对每一行 line（strip 后）:
    - 空行 → 跳过
    - 行 == "# References" → 跳过（参考文献节）
    - 行以 "[数字]" 开头（如 [1]）→ 跳过（引用条目）
    - 若 chunks 为空 → 新建 chunk = line
    - 若 len(chunks[-1]) <= chunk_size（默认 256）→ 追加到当前 chunk（换行连接）
    - 否则 → 新建 chunk = line
    ↓
返回 chunks: list[str]
```

**设计意图**：

- 按**行**累积，保持段落结构，而非固定字符窗盲目切断
- `chunk_size` 控制**当前块**最大字符数，超长时新开一块
- 过滤参考文献，避免检索到无意义引用列表

**可选扩展**（demo/task2）：按 `# 标题` 切分，本仓库主路径用行累积，与参考 Worker 一致。

---

### F5：BGE 文本向量 + CLIP 图文向量

**入口**：每个 chunk 调用 `embedding.encode_text_and_image(chunk, markdown_path)`

**实现逻辑**：

```
输入: chunk 文本, markdown 文件路径（用于解析图片相对路径）

Step 1 — 分离图文行
    text_with_no_image = 所有不以 "![" 开头的行，用 \n 拼接
    text_with_image    = 所有以 "![" 开头的行（Markdown 图片语法）

Step 2 — BGE 编码（检索主向量，512 维）
    text_bge = BGE.encode(text_with_no_image, normalize=True)
    失败 → 零向量 [0]*512

Step 3 — CLIP 文本编码（1024 维，跨模态对齐）
    text_clip = CLIP.encode(text_with_no_image, normalize=True)
    失败 → 零向量 [0]*1024

Step 4 — CLIP 图像编码（若 chunk 含图片行）
    从 "![" 行解析: ](path) 中的 path
    image_real_path = dirname(markdown_path) + "/" + basename(path)
    image_clip = CLIP.encode(image_real_path, normalize=True)
    无图或失败 → 零向量 [0]*1024

Step 5 — 返回 (text_bge, text_clip, image_clip)
```

**Mock 模式**（`USE_MOCK_EMBEDDING=true`）：

- 对文本做 MD5 种子 → 生成确定性随机单位向量，保证同文本同向量、无需 GPU

**写入向量库的一条记录**：

```python
{
  "text_vector": text_bge,           # 用于检索（F7）
  "clip_text_vector": text_clip,     # 预留跨模态检索
  "clip_image_vector": image_clip,   # 预留以图搜文
  "text": chunk,
  "db_id": file_id,
  "file_name": file_name,
  "file_path": file_path,
}
```

---

### F6：向量存储与按 db_id 删除

**入口**：`vector_store.get_vector_store()` 按配置返回实现类

**实现逻辑 — 插入**（`indexing.index_markdown_file` 循环内）：

```
for chunk in chunks:
    向量三元组 = encode_text_and_image(...)
    store.insert(record)
```

**实现逻辑 — 检索**（见 F7）：对 `text_vector` 做相似度排序。

**实现逻辑 — 删除**（`DELETE /files/{id}` 或 Streamlit 删除按钮）：

```
delete_file(file_id):
    1. SQLite DELETE files WHERE id = file_id
    2. os.remove(filepath) 若磁盘文件存在
    3. store.delete_by_db_id(file_id)
```

**三种存储后端**：

| 模式 | 类 | insert | search | delete_by_db_id |
|------|-----|--------|--------|-------------------|
| `local` | `LocalJsonVectorStore` | append + 写 `data/vector_store.json` | numpy 点积 Top-K | 过滤后重写 JSON |
| `milvus` | `MilvusVectorStore` | `MilvusClient.insert(collection=rag_data_new)` | `anns_field=text_vector` | `filter=f"db_id == {id}"` |
| `memory` | `MemoryVectorStore` | 内存 list | 点积排序 | 内存过滤（仅测试） |

---

### F7：问题向量检索 Top-K

**入口**：`POST /chat` → `RetrievalService.retrieve(question, top_k)`

**实现逻辑**：

```
Step 1 — 问题编码
    qvec = EmbeddingService.encode_query(question)   # 与 chunk 相同 BGE/Mock

Step 2 — 向量检索
    hits = vector_store.search(qvec, top_k=top_k)
    # local/memory: 对所有记录的 text_vector 计算 dot(qvec, vec)，降序取 Top-K
    # milvus: client.search(anns_field="text_vector", limit=top_k)

Step 3 — 路径修正（见 F8）
    for hit in hits:
        hit.text = fix_image_paths(hit.text, hit.file_path)

Step 4 — 返回 List[RetrievedChunk]
```

**说明**：当前问答主路径仅用 **BGE `text_vector`** 检索，与参考 `web_page_chat.py` 一致；`clip_*` 字段已写入，可供后续「以图搜文」扩展。

---

### F8：图片路径修正

**入口**：`RetrievalService.fix_image_paths(text, file_path)`

**实现逻辑**：

```
file_dir = basename(file_path).split(".")[0]   # 如 uploads/abc.pdf → abc
prefix = "./processed/{file_dir}/vlm/images/"

return text.replace("images/", prefix)
```

**示例**：

```
原文: ![](images/fig1.png)
修正: ![](processed/abc/vlm/images/fig1.png)
```

**目的**：MinerU 输出的 md 使用相对路径 `images/`，问答展示或 LLM 引用时需转为可访问的本地/静态路径（与参考项目 L100-101 一致）。

---

### F9：RAG Prompt + Qwen 回答

**入口**：`QAService.answer(question, context, sources)`

**实现逻辑**：

```
Step 1 — 拼装上下文
    context = "\n".join(各 chunk 的 text)   # 已由 F7/F8 处理

Step 2 — 构造 Prompt（模板 RAG_PROMPT）
    包含: 用户问题、相关资料、回答要求（客观、保留图片链接、注明来源）

Step 3 — 调用 LLM
    若 USE_MOCK_LLM=true:
        返回摘要式 Mock + 【来源】文件名列表
    否则:
        OpenAI(api_key, base_url).chat.completions.create(
            model=LLM_MODEL,   # 默认 qwen-plus
            messages=[system, user(RAG_PROMPT)]
        )
        若答案无【来源】行 → 追加来源文件名

Step 4 — 返回 answer 字符串
```

**API 层封装**（`app/api/chat.py`）：

```
retrieve → build_context → qa.answer
同时构造 sources[]: 每个 chunk 的 file_name, file_path, snippet(前200字)
返回 ChatResponse { answer, sources, retrieved_chunks }
```

---

### F10：文件列表与删除

**GET /files**：

```
SessionLocal → query(File).all()
→ 映射为 FileItem { id, filename, filepath, filestate, knowledge_base_id }
```

**DELETE /files/{file_id}**：

```
见 F6 删除逻辑；Streamlit 删除按钮调用相同 vector_store + ORM 操作
```

---

### F11：Streamlit 双页导航

**入口**：`web_ui/web_demo.py`

**实现逻辑**：

```
st.navigation([
    Page("web_page_upload.py", title="文件管理"),
    Page("web_page_chat.py", title="图文对话"),
])
pg.run()
```

**文件管理页**（`web_page_upload.py`）：

- 列表展示 `files` 表所有记录
- 上传 → 写盘 + ORM + `schedule_index()`（与 API 相同业务）
- 删除 → ORM + 删盘 + `delete_by_db_id`

**图文对话页**（`web_page_chat.py`）：

- `st.session_state.messages` 保存多轮对话
- `st.chat_input` 接收问题 → `RetrievalService` + `QAService`（**不经过 HTTP**，直接调 services）
- `render_markdown_with_images()`：正则匹配 `![](url)`，分段 `st.markdown` + `st.image`

---

### F12：课程评测脚本

**入口**：`app/services/evaluation.py`，测试见 `tests/test_evaluation.py`

**实现逻辑**：

对每条测试样本 `{ question, expected_file, expected_page_hint, expected_answer_keywords }` 和模型答案 `answer`、可选标准答案 `reference_answer`：

```
1. 文件名匹配分（满分 0.25）
   若 expected_file 子串出现在 answer 中 → 0.25，否则 0

2. 页面匹配分（满分 0.25）
   若未配置 expected_page_hint → 给满分 0.25（无页码要求）
   若配置了且 page_hint 在 answer 中 → 0.25，否则 0

3. 内容相似分（满分 0.5）
   jaccard = |chars(answer) ∩ chars(reference)| / |chars(answer) ∪ chars(reference)|
   content_score = jaccard * 0.5
   若 answer 包含任一 expected_answer_keywords → content_score = max(content_score, 0.25)

4. total = min(filename_score + page_score + content_score, 1.0)
```

**Jaccard 定义**：按**字符集合**交并比（与课程 README 一致），非分词级别。

---

### 端到端串联（上传 → 问答）

```mermaid
sequenceDiagram
    participant U as 用户
    participant API as FastAPI/Streamlit
    participant DB as SQLite
    participant IDX as indexing
    participant VS as vector_store
    participant LLM as QAService

    U->>API: 上传 PDF/MD
    API->>DB: INSERT filestate=uploaded
    API->>IDX: schedule_index (后台线程)
    API-->>U: 立即返回 file_id

    IDX->>DB: filestate=parsing
    IDX->>IDX: MinerU / 复制 md
    IDX->>IDX: split_text2chunks
    IDX->>IDX: encode_text_and_image × N
    IDX->>VS: insert × N
    IDX->>DB: filestate=indexed

    U->>API: POST /chat {question}
    API->>VS: search(text_vector, top_k)
    API->>API: fix_image_paths
    API->>LLM: RAG_PROMPT + context
    LLM-->>API: answer
    API-->>U: answer + sources
```

---

## 三、规定的实现方式

### 3.1 架构分层（必须遵守）

```
web_ui/          → 仅调用 app.services / app.api 业务层，不写重复逻辑
app/api/         → FastAPI 路由，参数校验，调用 services
app/services/    → 业务：chunking、embedding、vector_store、retrieval、qa、indexing
app/worker/      → Kafka 消费者，内部复用 indexing.process_upload_message
app/models/      → SQLAlchemy ORM（files 表）
```

**禁止**：在 API 与 Streamlit 中各写一套检索逻辑。

### 3.2 接口实现方式（对齐 README）

| 接口 | 方法 | 实现要点 |
|------|------|----------|
| `/upload/document` | POST multipart | uuid 存盘 → ORM insert → `indexing.schedule_index(file_id)` |
| `/chat` | POST JSON | BGE encode → vector search `text_vector` → fix paths → `qa.answer` |
| `/files` | GET | 查 SQLite |
| `/files/{id}` | DELETE | 删文件、ORM、向量 `delete_by_db_id` |
| `/health` | GET | `{"status":"ok"}` |

### 3.3 离线索引（Worker）实现方式

对齐 `offline_precess_worker.py`，并修正参考代码 bug：

1. 消费 Kafka `{id, file_name, file_path}`  
2. `mineru -p {path} -o ./processed`（**统一目录名 processed**，不用 precessed）  
3. `glob(processed/{basename}/**/*.md)`  
4. 对每个 chunk 调用 `encode_text_and_image` → `vector_store.insert`  
5. 更新 `filestate`：`uploaded` → `parsing` → `indexed` / `failed`

**无 Kafka 时**：`INDEX_MODE=inline`，上传接口后台线程执行相同 `process_upload_message`。

### 3.4 向量库实现方式（三选一，`.env` 配置）

| 模式 | 变量 | 场景 |
|------|------|------|
| `local` | `VECTOR_STORE_MODE=local` | 默认；JSON 持久化到 `data/vector_store.json`，本地作业可跑通 |
| `milvus` | `VECTOR_STORE_MODE=milvus` | 对接 Zilliz，collection `rag_data_new` |
| `memory` | 仅测试 | pytest 自动使用，不持久化 |

### 3.5 模型与外部依赖

| 组件 | 实现方式 | 环境变量 |
|------|----------|----------|
| BGE | `sentence_transformers` 或 Mock | `BGE_MODEL_PATH`，`USE_MOCK_EMBEDDING` |
| CLIP | `jina-clip-v2` 或 Mock | `CLIP_MODEL_PATH` |
| LLM | OpenAI 兼容（DashScope Qwen）或 Mock | `OPENAI_API_KEY`，`OPENAI_BASE_URL`，`LLM_MODEL` |
| MinerU | subprocess，可选跳过 | `PARSE_MODE=mineru\|markdown\|auto` |

### 3.6 配置与安全

- 所有密钥仅来自 `.env`，不得提交真实 Key。  
- 提供 `.env.example` 与 `README.md` 启动说明。

---

## 四、数据模型（与参考一致）

**SQLite `files`**：`id, filename, filepath, filestate, knowledge_base_id`

**向量记录字段**：`text_vector(512), clip_text_vector(1024), clip_image_vector(1024), text, db_id, file_name, file_path`

**状态流转**：`uploaded` → `parsing` → `indexed` | `failed`

---

## 五、测试要求

| 测试文件 | 覆盖 |
|----------|------|
| `test_chunking.py` | F4 切分规则 |
| `test_api.py` | F1/F7/F10 HTTP |
| `test_retrieval_mock.py` | F7/F8 |
| `test_indexing.py` | 内联索引 markdown |
| `test_evaluation.py` | F12 评测 |

运行：`pytest tests/ -v`

---

## 六、作业提交物

1. 本 `REQUIREMENTS.md`（功能清单 + 实现规定）  
2. `ARCHITECTURE.md`  
3. 可运行代码：`app/` + `web_ui/` + `tests/`  
4. `README.md`（安装、启动 API / Streamlit / Worker）  
5. 测试全部通过截图或命令输出  

---

## 七、完成定义（Definition of Done）

- [x] 上述 F1–F12 均有对应代码  
- [x] FastAPI 四个核心路由可调用  
- [x] 默认 `local` 向量库 + `inline` 索引，无 Milvus/Kafka 可演示  
- [x] Streamlit 与参考项目功能对齐  
- [x] `pytest` 全绿  
