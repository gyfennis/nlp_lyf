"""文件管理页 — 对齐参考 web_page_upload.py，调用统一 services"""

import os
import sys
import uuid

import streamlit as st

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app.models.orm import File as FileModel, SessionLocal
from app.services.indexing import schedule_index
from app.services.vector_store import get_vector_store

st.markdown("### 文件管理")


def delete_file(file_id: int):
    with SessionLocal() as session:
        record = session.query(FileModel).filter(FileModel.id == file_id).first()
        if not record:
            st.error("文件不存在")
            return
        path = record.filepath
        session.delete(record)
        session.commit()
    if path and os.path.exists(path):
        os.remove(path)
    get_vector_store().delete_by_db_id(file_id)
    st.success("文件删除成功")
    st.rerun()


with SessionLocal() as session:
    files = session.query(FileModel).all()

if files:
    for f in files:
        cols = st.columns([3, 1])
        with cols[0]:
            st.write(f"`{f.id}` | {f.filename} | 状态: **{f.filestate}** | {f.filepath}")
        with cols[1]:
            if st.button("删除", key=f"del_{f.id}"):
                delete_file(f.id)
else:
    st.warning("没有找到任何文件记录。")

st.markdown("### 文件上传")
uploaded = st.file_uploader("上传文件", type=["pdf", "docx", "txt", "md"])
if uploaded is not None:
    from app.core.config import get_settings

    settings = get_settings()
    os.makedirs(settings.upload_dir, exist_ok=True)
    ext = os.path.splitext(uploaded.name)[1]
    save_path = os.path.join(settings.upload_dir, str(uuid.uuid4()) + ext)
    with open(save_path, "wb") as f:
        f.write(uploaded.getvalue())

    with SessionLocal() as session:
        record = FileModel(
            filename=uploaded.name,
            filepath=save_path,
            filestate="uploaded",
        )
        session.add(record)
        session.commit()
        session.refresh(record)

    schedule_index(record.id, record.filename, save_path)
    st.success(f"已上传 {uploaded.name}，后台索引中（file_id={record.id}）")
