"""Streamlit 导航入口 — 对齐参考 web_demo.py"""

import streamlit as st

pg = st.navigation(
    [
        st.Page("web_page_upload.py", title="文件管理"),
        st.Page("web_page_chat.py", title="图文对话"),
    ]
)
pg.run()
