"""图文对话页 — 对齐参考 web_page_chat.py"""

import os
import re
import sys

import streamlit as st

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app.services.qa import QAService
from app.services.retrieval import RetrievalService

st.set_page_config(page_title="图文对话", layout="wide")


def clear_chat_history():
    st.session_state.messages = [
        {"role": "system", "content": "你好，我是多模态 RAG 助手，请基于知识库提问。"}
    ]


if "messages" not in st.session_state:
    clear_chat_history()

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

with st.sidebar:
    st.button("清空当前聊天", on_click=clear_chat_history, use_container_width=True)


def render_markdown_with_images(markdown_text: str):
    pattern = re.compile(r"!\[.*?\]\((.*?)\)")
    last_pos = 0
    for match in pattern.finditer(markdown_text):
        st.markdown(markdown_text[last_pos : match.start()], unsafe_allow_html=True)
        img_url = match.group(1)
        if os.path.exists(img_url.lstrip("./")):
            st.image(img_url)
        else:
            st.caption(f"图片: {img_url}")
        last_pos = match.end()
    st.markdown(markdown_text[last_pos:], unsafe_allow_html=True)


if prompt := st.chat_input("输入问题..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    retrieval = RetrievalService()
    chunks = retrieval.retrieve(prompt, top_k=5)
    context = retrieval.build_context(chunks)
    sources = [{"file_name": c.file_name, "file_path": c.file_path, "snippet": c.text[:200]} for c in chunks]

    qa = QAService()
    answer = qa.answer(prompt, context, sources)

    with st.chat_message("assistant"):
        render_markdown_with_images(answer)

    st.session_state.messages.append({"role": "assistant", "content": answer})
