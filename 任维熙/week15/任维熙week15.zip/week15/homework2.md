# 作业2：MinerU 与 pdfplumber 文档解析效果对比

MinerU 是在线/本地跑一套版面分析、OCR、公式识别、表格识别再加规则后处理的流水线，输出带标题层级、LaTeX 公式、图片路径和表格结构的 Markdown；pdfplumber 则是直接读 PDF 内嵌文字层的坐标信息，用 `extract_text()` 和 `extract_tables()` 把字和表格抠出来，没有 OCR，也不做版面语义分类。前者偏重「还原给人看的文档」，后者偏重「从数字版 PDF 里快速取字」。

双栏论文或技术报告上差别最明显。MinerU 会先做 layout，再按阅读顺序重排段落，导出的 Markdown 一般能顺着读下来。pdfplumber 往往按 PDF 内部存储顺序吐字，左栏没读完就接到右栏，段落被打成一串，拿去做 RAG 分块时噪声很多。含公式的学术 PDF 更明显：MinerU 用公式检测和识别模块，行内、行间公式能落成 LaTeX；pdfplumber 只能拿到文字层里的 Unicode，常见结果是乱码或符号被拆散，基本没法检索或给模型当上下文。表格方面，MinerU 走专用表格识别，能导出较完整的结构；pdfplumber 对有线框、版式规整的表还能抽出二维数组，遇到合并单元格、无框线或嵌套表时列经常错位，后面还得自己洗。图片和图注 MinerU 会裁图并在 Markdown 里挂链接，图注和正文关系保留得相对清楚；pdfplumber 拿不到这种「图 + 说明」的语义包，做多模态 RAG 时往往缺图这一侧的信息。

扫描版 PDF 上两者几乎不在一个量级。MinerU 预处理里会判断是不是扫描件，是的话走 OCR；pdfplumber 没有 OCR，扫描页基本抽不出字，要自己做就得再接别的识别库。页眉、页脚、页码在 MinerU 里会被标成 discard 并在后处理去掉；pdfplumber 默认和正文一起抽出，不清洗的话很容易进知识库。部署成本也不一样：MinerU 更重，最好有 GPU，在线 Extractor（https://mineru.net/OpenSourceTools/Extractor）适合先试效果；pdfplumber 轻，pip 装上就能在脚本里跑。

综合来看，电子版、版式简单、只要纯文本或固定格式表格的 PDF，用 pdfplumber 更省事、延迟低，做统计或字段固定的抽取够用。要把教材、研报、论文这类复杂文档解析成可读 Markdown 再进 RAG 或训练语料，MinerU 效果明显更好，和课程里 Worker 消费 MinerU 输出再切块入库的路径也对得上。并不是二选一：文字层干净、只抽几页正文时 pdfplumber 够用；要尽量还原版式、公式、图表和阅读顺序，还是 MinerU 更合适，项目里也可以 pdfplumber 看页数元数据、正文仍交给 MinerU。
